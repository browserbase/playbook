
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="3bf5fa9d-18fd-5410-b049-330ef4ff4b2c")}catch(e){}}();
import{c as t}from"/chunks/chunk-2KYCOQX6.js";import"/chunks/chunk-7AV6Z32H.js";import"/chunks/chunk-54UHBIHR.js";var d=t()??"double-pane";document.body.setAttribute("data-width",d);

//# debugId=3bf5fa9d-18fd-5410-b049-330ef4ff4b2c
